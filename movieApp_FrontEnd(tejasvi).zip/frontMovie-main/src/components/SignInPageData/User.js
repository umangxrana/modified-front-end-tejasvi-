import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Menus.css';
import './MainCSS.css';
function User(){
    return (
        <div> <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container">
          <Link className="navbar-brand" to="/">MovieBook App</Link>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/User">Home</Link>
              </li>
              
              <li className="nav-item">
                <Link className="nav-link" to="/AddTicket">Add Ticket</Link>
              </li>
              <li className="nav-item">
              <Link className="nav-link" to="/AddMovieForm">Add Movie</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/AllMovie">Movies List</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/DeleteMovie">Delete Movie</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/AllTicket">Bookings</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/">Logout</Link>
            </li>
            </ul>
          </div>
        </div>
      </nav>
        <div className="container-fluid">
        <div className='blur-background'>
        <header>
            <h1 id='header1'>Welcome to the Movie Booking App</h1>
          </header>
          <section id='header2'>
            <p>Explore the latest movies and book your tickets online.</p>
          </section>
        </div>
        </div>
        </div>
      );
}

export default User;